jQuery(document).ready(function ($) {
    $('.banner_sect .row1.slider').slick({
        autoplaySpeed: 3000,
        autoplay: true,
    });
});